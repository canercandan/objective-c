# 1 "test72.c"
# 1 "/sw/packages/cygnus/progressive-97r1/sparc-sun-solaris2.5.1/lib/gcc-lib/sparc-sun-solaris2.5.1/2.7-97r1/include/stdio.h" 1 3
# 1 "test72.c" 2
char f;
m()
{
(
!(
f     +
3 &3)
-1)
;
}


