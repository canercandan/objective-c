typedef double floatp;

int     gs_set(float (*)(floatp, floatp ) );

