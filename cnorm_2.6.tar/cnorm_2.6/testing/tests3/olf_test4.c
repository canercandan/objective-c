int a,b;
int f() {
    a = 1, b = 2;
}

