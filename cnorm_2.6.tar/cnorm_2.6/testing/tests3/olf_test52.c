
funfn(int a, int b, int c, int d, char *e)
{
        if (a) {
                print();
                return b;
        }
        if (b) {
                int localfn() {
                        return a;
                }
                exit(c);
                
        }
        if (d) {
                __builtin_return( null );
        }
        return c;
}

fn() {
        print("whoa");
}

fn2() {
        if (1)
                return 2;
}

main() {
        malloc(10);
        nonMalloc(20);
        fn();
        funfn(1,2,3,4,"hey");
}

