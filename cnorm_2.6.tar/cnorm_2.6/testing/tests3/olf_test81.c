# 1 "930927-1.c"
# 1 "/sw/packages/cygnus/progressive-97r1/sparc-sun-solaris2.5.1/lib/gcc-lib/sparc-sun-solaris2.5.1/2.7-97r1/include/stddef.h" 1 3
# 61 "/sw/packages/cygnus/progressive-97r1/sparc-sun-solaris2.5.1/lib/gcc-lib/sparc-sun-solaris2.5.1/2.7-97r1/include/stddef.h" 3
typedef int ptrdiff_t;
typedef unsigned int size_t;
typedef long int wchar_t;
typedef unsigned int  wint_t;
# 302 "/sw/packages/cygnus/progressive-97r1/sparc-sun-solaris2.5.1/lib/gcc-lib/sparc-sun-solaris2.5.1/2.7-97r1/include/stddef.h" 3
# 1 "930927-1.c" 2
wchar_t s[5] = L"abcd";

