// C++ comment

int f$;

     tester (int len; char data[len][len], int len) {

        }

