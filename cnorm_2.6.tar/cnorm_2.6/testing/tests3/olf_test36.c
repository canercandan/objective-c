typedef struct {
    } ff6tfdrg;

