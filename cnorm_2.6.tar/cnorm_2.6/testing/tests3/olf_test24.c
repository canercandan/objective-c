
struct foo {int a[5];} ;
struct foo f();

inline int bar (int index) {
        int c;
        enum blah;
        c = __alignof(foo.a);
        c = __alignof(unsigned long int);
        switch (index) {
        case 'a'...'z':
                break;
        }
        return f().a[index];

}

