f (__builtin_va_alist )
     int __builtin_va_alist;...
{ }

