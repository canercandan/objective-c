void * validate_malloc(typeof(sizeof(0)) size, void *pc);
void * get_current_pc(void);
void fn_entry(int functionId);
void fn_exit(int functionId);

main() {
        exit(0);
}

