
void F(char l)
{
        return l<= '\~';
}

