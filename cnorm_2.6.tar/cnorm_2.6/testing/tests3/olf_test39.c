typedef struct x_ x;
struct x_{
int y;
int z;
};
x b;

struct x_ a = {};

x c = {};

typedef struct xyz_ {
int a;
  int b;;
char c;
} xyz;

