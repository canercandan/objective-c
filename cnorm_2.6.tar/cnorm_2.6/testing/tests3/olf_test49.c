typedef struct gh554j_ {
    long x2;
    char *x3;
} gh554j;
 void 
ad (int *x3, int *x4)
{
        gh554j x1;
    if (x3 && x4) {
        char gh554j[19];  
        gh554j[0]='\n';
    }

}

