f ()
{
  __label__ l;
  void *x()
    {
      return &&l;
    }
l:
}


