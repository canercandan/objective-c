struct s {
  int c[3];
};

struct s s = {
  c: {1, 2, 3}
};

