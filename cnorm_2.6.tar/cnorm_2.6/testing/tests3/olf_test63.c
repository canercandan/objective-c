x(a)
{
    static void*j[]={&&l1};
    goto*j[a];
l1:
}

