
struct foo {int a[5];} ;
struct foo f();

inline int bar (int index) {
        int c;
        enum blah;
        return f().a[index];

}

