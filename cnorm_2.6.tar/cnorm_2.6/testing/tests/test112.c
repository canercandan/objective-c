
typedef struct a {
        int b;
        } c,*d;

//extern int execv(const char *, char *const []);
int b;
int a = b = 1;
static char *predefs = "whatever \
more ";
static char cPickle_module_documentation[] = 
"C implementation and optimization of the Python pickle module\n"
"\n"
"cPickle.c,v 1.48 1997/12/07 14:37:39 jim Exp\n"
;

