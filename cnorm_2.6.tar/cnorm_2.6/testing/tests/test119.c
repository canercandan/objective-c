        enum { DDD = -7 };


struct abc_ {
        struct abc *next;
        int a;
        char b;
};

