struct s
{
  int a;
  int b;
  short c;
  int d[3];
};
struct s _s = {3, {2,0,0} };

