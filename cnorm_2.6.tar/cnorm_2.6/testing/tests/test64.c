int f()
{
__label__ l;
l:p();
}

