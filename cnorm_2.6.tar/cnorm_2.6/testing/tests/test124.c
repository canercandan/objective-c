int x;

int y;

int test(){
switch (x) {
 case 1: y=3;
    break;
 case 2: y=90;
    break;
 default:
}

if (x<10) {
goto l66;
} else {
y=100;
 y++;
l66:
}

}

