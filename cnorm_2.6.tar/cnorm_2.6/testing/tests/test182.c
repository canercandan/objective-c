void*    test(void)
{
    unsigned long long tamaire;
    if(tamaire != 'TOTO') {
        return ((void *)0);
    }
}
