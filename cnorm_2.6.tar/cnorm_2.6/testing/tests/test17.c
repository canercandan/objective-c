int heynow() {
    long long int x = 10LL;
    unsigned long long int y = 9ULL;
    __complex__ float c, d, e;
    float f;
    c = 10.0 + 3.0fi;
    d = ~ c;
    f = __real__ c;
    f = __imag__ d;
}    

