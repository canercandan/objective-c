extern void rt(long, long);
extern long rn(void);
extern void rl(char*, int, int);
int    rd  (void **, int)  ;
int rf (int *rnx)
{
                return (rnx);
}

int rnn (int rny)
{
                return (rny);
}
// ;                               
// ;
extern const int XYZ ; //;
// ;

