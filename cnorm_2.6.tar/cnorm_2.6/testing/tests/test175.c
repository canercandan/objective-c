int main()
{
  if (! '0' != 0);
}

