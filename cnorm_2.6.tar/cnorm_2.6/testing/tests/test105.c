int hey(int a) {
    int x,y,z;
    z= x ? : y;
}

