typedef unsigned char uchar;
typedef struct _hgfretty {
    uchar bvfetgl;
    uchar aytrffr[80 ];
} hgfretty;

typedef struct  pojeqsd {
    char                        hgfretty_[99 ];
  hgfretty b;
} pojeqsd_t;

