void * validate_malloc(/*typeof(sizeof(0))*/int size, void *pc);
void * get_current_pc(void);
void fn_entry(int functionId);
void fn_exit(int functionId);

int main() {
        exit(0);
}

