int main()
{
  if (! L'\0' != 0);
}

