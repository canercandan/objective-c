typedef long time_t;

static time_t
f (
   __const time_t janfirst,
   register __const int * __const rulep)
{
}

