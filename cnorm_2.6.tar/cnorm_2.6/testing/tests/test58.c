int g ();
int f ()
{
  int seed;
  g (seed);
}

