typedef struct d4elhhtrt_ {
    int alhhtrt : 6;             
    int bblhhtrt : 6;            
  int  uyttffds:3;//  __attribute__ ((packed)) ;  
  int  hfgeresshb:5;//  __attribute__ ((packed)) ;                
} d4elhhtrt;

