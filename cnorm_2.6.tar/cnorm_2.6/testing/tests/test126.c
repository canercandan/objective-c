typedef struct  g667h_  g667h  ;
struct g667h_ {
    const char *ttc;
    const char *e;
    const char *t;
};


int dddd()
{

g667h hhhh, ttt;

}

