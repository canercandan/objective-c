int * f(char);
char * b;
int main(int ac, char **av) {
  int a;
        
  a = f(*b)[4]; /* indirect on "b", call "f", and index the result
                  /* by "4" */
        }

