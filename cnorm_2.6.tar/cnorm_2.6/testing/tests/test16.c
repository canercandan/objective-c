int hey() {
    int x,y,z;
    z= x ? : y;
}

