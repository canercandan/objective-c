//long int s[5] = L"abcd";
char *s = "abcd";

