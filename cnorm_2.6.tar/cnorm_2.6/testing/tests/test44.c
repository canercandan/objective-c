#pragma whoa nellie
int a;
#
#ident something
#pragma something else

int main() {
        exit(0);
#ident heynow
}

