     double foo (double a, double b)
     {
       auto double square (double z);
       double square (double z) { return z * z; }
     
       return square (a) + square (b);
     }

