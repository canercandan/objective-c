typedef enum {
    F_FE,                        
    F_U,                         
    F_E,                 
} yy;
int main() {
        exit(0);
}

