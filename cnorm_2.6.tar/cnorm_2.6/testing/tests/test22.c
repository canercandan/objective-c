int aikoAllDay() {
     int a[6] = { [4] 29, [2] = 15 };
     int ab[6] = { 0, 0, 15, 0, 29, 0 };
     int widths[] = { [0 ... 9] = 1, [10 ... 99] = 2, [100] = 3 };
    
     int xvalue, yvalue, v1, v2, v4;
     struct point { int x, y; };
     struct point p = { xvalue, yvalue };
    struct point p = { y: yvalue, x: xvalue };
     struct point p = { .y = yvalue, .x = xvalue };

     union foo { int i; double d; };
     union foo f = { d: 4 };

     int a[6] = { [1] = v1, v2, [4] = v4 };
     int a[6] = { 0, v1, v2, 0, v4, 0 };

     int whitespace[256]
       = { [' '] = 1, ['\t'] = 1, ['\h'] = 1,
           ['\f'] = 1, ['\n'] = 1, ['\r'] = 1 };
    fn(1,2,3);
}

