typedef int f;
char * b;
int main(int ac, char **av) {
        f(*b)[4]; /* redeclare "b" to be a pointer to 4 ints */
        }

