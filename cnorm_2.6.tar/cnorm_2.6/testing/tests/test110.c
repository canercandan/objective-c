
struct foo {int a[5];} ;
struct foo f();

inline int bar (int index) {
        int c;
        struct blah;
        return f().a[index];

}

