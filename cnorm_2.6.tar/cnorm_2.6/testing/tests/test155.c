
static inline void
ttt (int *wwp)
{
    int xyz = 6;
    do {
    } while (!xyz);
}

