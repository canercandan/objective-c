typedef unsigned char uchar;
typedef struct _hgfretty {
    uchar bvfetgl;
    uchar aytrffr[80 ];
} hgfretty;

typedef struct  pojeqsd {
    char                        t[99 ];
} pojeqsd_t;

