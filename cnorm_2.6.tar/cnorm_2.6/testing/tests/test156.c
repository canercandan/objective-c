static inline void
junk2 (void)
{
long gtexews;
}

