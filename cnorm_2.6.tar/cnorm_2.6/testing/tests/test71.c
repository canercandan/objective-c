int f (
       int __builtin_va_alist;...)
{

}

