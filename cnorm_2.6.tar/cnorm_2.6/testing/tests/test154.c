typedef struct ppptype_ {
    void *d;                     
    void *l;                     
    int t;                               
    int m;                       
} ppptype;
typedef struct  jjjtype_  jjjtype  ;             
//typedef __typeof__ (sizeof (0)) size_t;
typedef unsigned char uchar;
typedef unsigned short ushort;
typedef unsigned long ulong;
typedef ulong  cttype;
typedef char *zz_list;           
typedef int boolean;
typedef unsigned char tl;
typedef void abctype;
typedef int wwd_t;
typedef enum {
    F_FE,                        
    F_U,                         
    F_E,                 
} yy;
typedef void xyz;
typedef xyz (xyz_t)(void);
typedef abctype (abcproc)(void  );
typedef boolean (mnsss)(ppptype *);
typedef void (void_r)(void *, ...);
typedef boolean (boolean_e)(void *, ...);
typedef void (*tyyx_func)(void *, void *, void *);
typedef boolean (*bbhg_type)(jjjtype *);

typedef struct cl_ {
    union {
        uchar   y[4];
        ushort  s[2];
        ulong   d;
    } d;
} cl;

