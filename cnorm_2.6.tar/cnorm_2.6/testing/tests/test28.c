// C++ comment

//int f$;
int f;// no $ in identifier

int tester (int len; char data[len][len], int len) {

        }

