typedef int T;
int main() {
        int T_=100, a=(T)+1;
        //assert(101 == T);
        }    

