//enum { DDD = -7 };


struct abc_ {
        struct abc *next;
  //enum { DDD = -7 };
        int a;
        char b;
};

