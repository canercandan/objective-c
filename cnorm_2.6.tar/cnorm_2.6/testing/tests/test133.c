struct s {
  int c[3];
};

struct s d = {{1, 2, 3}};

