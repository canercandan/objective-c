int main(int ac, char **av) {
    int a;
 
    c = &a;
}
