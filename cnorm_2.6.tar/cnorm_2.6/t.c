int main(int ac, char* av[])
{
  int a;
  int b;

  a = 12 + 4 * 42 + (int)calc(123, 348);

  if (a && b)
    {
      printf("ok");
    }
  else
    {
      printf("ko");
    }
  return a;
}